int main() {
 
    /* a hasn't been declared here, this should throw an error */
    a = 5;
    
    return 0;   
    
}
