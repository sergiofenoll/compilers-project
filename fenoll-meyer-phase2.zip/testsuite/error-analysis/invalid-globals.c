/* Globals must be declared as constants */
int a = 5 + 5;
int b = a * 2;

int main() {
    
    return b;

}
