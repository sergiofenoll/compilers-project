int main() {

    /* There's a missing ';' here */
    int a = 5
    
    return 0;

}
