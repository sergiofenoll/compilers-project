/* This program has no main function, it can't be compiled */

int f() {
    int a = 5;
    
    if (a > 0) {
        return a;
    }
    
    return 0;
}
