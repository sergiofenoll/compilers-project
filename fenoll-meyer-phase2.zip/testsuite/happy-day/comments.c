#include <stdio.h>

int main(int argc, char** argv) {
    // This is a signle line comment
    // It will be ignored by the compiler
    // Even if there's code after it!
    // int a = 420;

    /* This is a block comment
     * You don't _need_ to format it like this,
     * but I like it this way because it looks pretty.
     * This comment too will ignore code!
     * int b = 22;
     * float f = 2.54;
     * printf("a: %d b: %d f: %f\n", a, b, f);
     */
	// The code below will be executed
	printf("Hello world!\n");
    return 0;
}
