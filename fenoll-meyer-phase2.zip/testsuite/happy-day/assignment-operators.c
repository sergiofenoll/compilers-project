#include <stdio.h>

int main(int argc, char** argv) {
    // Integer
    int ilhs = 10;
    int irhs = 4;

    // Addition
    printf("%d\n", ilhs += irhs);

    // Subtraction
    printf("%d\n", ilhs -= irhs);

    // Multiplication
    printf("%d\n", ilhs *= irhs);

    // Division
    printf("%d\n", ilhs /= irhs);

    // Float
    float flhs = 2.30;
    float frhs = 8.40;

    // Addition
    printf("%f\n", flhs += frhs);

    // Subtraction
    printf("%f\n", flhs -= frhs);

    // Multiplication
    printf("%f\n", flhs *= frhs);

    // Division
    printf("%f\n", flhs /= frhs);

    // Char
    char clhs = 'a';
    char crhs = 'A';

    // Addition
    printf("%c\n", clhs += crhs);

    // Subtraction
    printf("%c\n", clhs -= crhs);

    // Multiplication
    printf("%c\n", clhs *= crhs);

    // Division
    printf("%c\n", clhs /= crhs);
    return 0;
}