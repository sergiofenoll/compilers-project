#include <stdio.h>

int main() {

    int a = 5;
    float b = a + 5.0;
    int c = b * 2;

    return 0;
}